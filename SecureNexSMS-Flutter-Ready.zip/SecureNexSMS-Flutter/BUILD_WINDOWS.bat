@echo off
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found in PATH. Install Flutter and reopen this terminal.
  pause
  exit /b 1
)
call flutter pub get
if errorlevel 1 goto :error
call flutter clean
if errorlevel 1 goto :error
call flutter build apk --release
if errorlevel 1 goto :error
echo.
echo APK created at build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0
:error
echo Build failed. Review the error above.
pause
exit /b 1
