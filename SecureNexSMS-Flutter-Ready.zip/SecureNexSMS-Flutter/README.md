# SecureNex SMS — Flutter

Flutter user interface with the original native Android SMS gateway engine retained for reliable background SMS/MMS, FCM, delivery reports, heartbeat, dual-SIM selection and boot restart.

## Requirements
- Flutter stable (3.24 or newer recommended)
- Android Studio with Android SDK 35
- JDK 17
- A Firebase Android app for package `com.httpsms`

## Firebase
The supplied `android/app/google-services.json` is included. If you use a different Firebase project, replace it with a JSON file whose Android package is exactly `com.httpsms`.

## Build
```bash
flutter pub get
flutter clean
flutter build apk --release
```
APK output:
`build/app/outputs/flutter-apk/app-release.apk`

For Play Store:
```bash
flutter build appbundle --release
```

## Signing
The release build currently uses the debug signing key so it can be built immediately. Before publishing, create a release keystore and replace the signing configuration in `android/app/build.gradle.kts`.

## Important Android settings
Grant SMS, phone-state and notification permissions. Disable battery optimization for reliable background operation. Some manufacturers also require enabling Auto Launch/background activity manually.
