package com.httpsms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.httpsms.services.StickyNotificationService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import timber.log.Timber
import java.net.URI
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "com.httpsms/native"
    private val executor = Executors.newSingleThreadExecutor()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        if (Timber.treeCount == 0) Timber.plant(Timber.DebugTree())
        Receiver.register(applicationContext)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "getState" -> result.success(stateMap())
                "requestPermissions" -> {
                    requestRuntimePermissions()
                    result.success(true)
                }
                "login" -> {
                    val apiKey = call.argument<String>("apiKey")?.trim().orEmpty()
                    val serverUrl = call.argument<String>("serverUrl")?.trim().orEmpty()
                    val sim1 = call.argument<String>("sim1")?.trim().orEmpty()
                    val sim2 = call.argument<String>("sim2")?.trim().orEmpty()
                    login(apiKey, serverUrl, sim1, sim2, result)
                }
                "saveSettings" -> {
                    saveSettings(call.arguments as? Map<*, *> ?: emptyMap<Any, Any>())
                    result.success(stateMap())
                }
                "heartbeat" -> heartbeat(result)
                "logout" -> {
                    logout()
                    result.success(stateMap())
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun stateMap(): Map<String, Any?> = mapOf(
        "loggedIn" to Settings.isLoggedIn(this),
        "sim1" to Settings.getSIM1PhoneNumber(this),
        "sim2" to Settings.getSIM2PhoneNumber(this),
        "dualSim" to Settings.isDualSIM(this),
        "sim1Outgoing" to Settings.getActiveStatus(this, Constants.SIM1),
        "sim2Outgoing" to Settings.getActiveStatus(this, Constants.SIM2),
        "sim1Incoming" to Settings.isIncomingMessageEnabled(this, Constants.SIM1),
        "sim2Incoming" to Settings.isIncomingMessageEnabled(this, Constants.SIM2),
        "sim1Calls" to Settings.isIncomingCallEventsEnabled(this, Constants.SIM1),
        "sim2Calls" to Settings.isIncomingCallEventsEnabled(this, Constants.SIM2),
        "encrypt" to Settings.encryptReceivedMessages(this),
        "encryptionKey" to (Settings.getEncryptionKey(this) ?: ""),
        "debugLogs" to Settings.isDebugLogEnabled(this),
        "serverUrl" to Settings.getServerUrlOrDefault(this).toString(),
        "lastHeartbeat" to Settings.getHeartbeatTimestamp(this)
    )

    private fun login(apiKey: String, serverUrl: String, sim1: String, sim2: String, result: MethodChannel.Result) {
        if (apiKey.isBlank() || sim1.isBlank()) {
            result.error("INVALID_INPUT", "API key and SIM 1 phone number are required", null)
            return
        }
        val uri = try { URI(serverUrl.ifBlank { "https://api.httpsms.com" }) } catch (_: Exception) {
            result.error("INVALID_URL", "Server URL is invalid", null); return
        }
        FirebaseMessaging.getInstance().token.addOnCompleteListener { tokenTask ->
            if (!tokenTask.isSuccessful || tokenTask.result.isNullOrBlank()) {
                result.error("FCM_ERROR", "Could not obtain Firebase token", null)
                return@addOnCompleteListener
            }
            val token = tokenTask.result
            executor.execute {
                try {
                    val api = HttpSmsApiService(apiKey, uri)
                    val response = api.updateFcmToken(sim1, Constants.SIM1, token)
                    if (response.first == null) {
                        runOnUiThread { result.error("LOGIN_FAILED", response.second ?: response.third ?: "Server rejected login", null) }
                        return@execute
                    }
                    Settings.setApiKeyAsync(this, apiKey)
                    Settings.setServerUrlAsync(this, uri.toString())
                    Settings.setSIM1PhoneNumber(this, sim1)
                    Settings.setSIM2PhoneNumber(this, sim2.ifBlank { null })
                    Settings.setUserID(this, response.first!!.userID)
                    Settings.setFcmTokenAsync(this, token)
                    Settings.setActiveStatusAsync(this, true, Constants.SIM1)
                    Settings.setIncomingActiveSIM1(this, true)
                    if (sim2.isNotBlank()) {
                        Settings.setActiveStatusAsync(this, true, Constants.SIM2)
                        Settings.setIncomingActiveSIM2(this, true)
                        api.updateFcmToken(sim2, Constants.SIM2, token)
                    }
                    runOnUiThread {
                        startStickyServiceIfNeeded()
                        result.success(stateMap())
                    }
                } catch (e: Exception) {
                    runOnUiThread { result.error("LOGIN_ERROR", e.message ?: e.javaClass.simpleName, null) }
                }
            }
        }
    }

    private fun saveSettings(values: Map<*, *>) {
        fun bool(name: String, default: Boolean) = values[name] as? Boolean ?: default
        Settings.setActiveStatusAsync(this, bool("sim1Outgoing", true), Constants.SIM1)
        Settings.setActiveStatusAsync(this, bool("sim2Outgoing", true), Constants.SIM2)
        Settings.setIncomingActiveSIM1(this, bool("sim1Incoming", true))
        Settings.setIncomingActiveSIM2(this, bool("sim2Incoming", true))
        Settings.setIncomingCallEventsEnabled(this, Constants.SIM1, bool("sim1Calls", false))
        Settings.setIncomingCallEventsEnabled(this, Constants.SIM2, bool("sim2Calls", false))
        Settings.setDebugLogEnabled(this, bool("debugLogs", false))
        val key = values["encryptionKey"] as? String
        Settings.setEncryptionKey(this, key?.trim()?.takeIf { it.isNotEmpty() })
        Settings.setEncryptReceivedMessages(this, bool("encrypt", false) && !key.isNullOrBlank())
        startStickyServiceIfNeeded()
    }

    private fun heartbeat(result: MethodChannel.Result) {
        executor.execute {
            try {
                val numbers = mutableListOf(Settings.getSIM1PhoneNumber(this))
                if (Settings.getSIM2PhoneNumber(this).isNotBlank()) numbers.add(Settings.getSIM2PhoneNumber(this))
                val ok = HttpSmsApiService.create(this).storeHeartbeat(numbers.toTypedArray(), Settings.isCharging(this))
                if (ok) Settings.setHeartbeatTimestampAsync(this, System.currentTimeMillis())
                runOnUiThread { result.success(ok) }
            } catch (e: Exception) {
                runOnUiThread { result.error("HEARTBEAT_ERROR", e.message, null) }
            }
        }
    }

    private fun logout() {
        stopService(Intent(this, StickyNotificationService::class.java))
        Settings.setApiKeyAsync(this, null)
        Settings.setSIM1PhoneNumber(this, null)
        Settings.setSIM2PhoneNumber(this, null)
        Settings.setUserID(this, null)
        Settings.setEncryptionKey(this, null)
        Settings.setEncryptReceivedMessages(this, false)
        Settings.setFcmTokenLastUpdateTimestampAsync(this, 0)
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(
            Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 9001)
    }

    private fun startStickyServiceIfNeeded() {
        if (!Settings.getActiveStatus(this, Constants.SIM1) && !Settings.getActiveStatus(this, Constants.SIM2)) return
        val intent = Intent(this, StickyNotificationService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }
}
