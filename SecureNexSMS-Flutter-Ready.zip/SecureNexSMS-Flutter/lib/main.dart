import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const SecureNexApp());

class NativeApi {
  static const _channel = MethodChannel('com.httpsms/native');
  static Future<Map<String, dynamic>> state() async =>
      Map<String, dynamic>.from(await _channel.invokeMethod('getState'));
  static Future<Map<String, dynamic>> login(Map<String, String> data) async =>
      Map<String, dynamic>.from(await _channel.invokeMethod('login', data));
  static Future<Map<String, dynamic>> save(Map<String, dynamic> data) async =>
      Map<String, dynamic>.from(await _channel.invokeMethod('saveSettings', data));
  static Future<bool> heartbeat() async => await _channel.invokeMethod('heartbeat') == true;
  static Future<Map<String, dynamic>> logout() async =>
      Map<String, dynamic>.from(await _channel.invokeMethod('logout'));
  static Future<void> permissions() => _channel.invokeMethod('requestPermissions');
}

class SecureNexApp extends StatefulWidget {
  const SecureNexApp({super.key});
  @override State<SecureNexApp> createState() => _SecureNexAppState();
}

class _SecureNexAppState extends State<SecureNexApp> {
  Map<String, dynamic>? state;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final s = await NativeApi.state(); if (mounted) setState(() => state = s); }
  @override Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SecureNex SMS',
      theme: ThemeData(colorSchemeSeed: const Color(0xff1368ce), useMaterial3: true),
      home: state == null
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : state!['loggedIn'] == true
              ? HomeScreen(state: state!, onChanged: _load)
              : LoginScreen(onLogin: (s) => setState(() => state = s)),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLogin});
  final ValueChanged<Map<String, dynamic>> onLogin;
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final apiKey = TextEditingController();
  final server = TextEditingController(text: 'https://api.httpsms.com');
  final sim1 = TextEditingController();
  final sim2 = TextEditingController();
  bool busy = false; String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      await NativeApi.permissions();
      final s = await NativeApi.login({'apiKey': apiKey.text, 'serverUrl': server.text, 'sim1': sim1.text, 'sim2': sim2.text});
      widget.onLogin(s);
    } on PlatformException catch (e) { setState(() => error = e.message ?? e.code); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 520), child: Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(
        mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.sms_rounded, size: 64), const SizedBox(height: 12),
          Text('SecureNex SMS', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8), const Text('Connect this Android phone to your SMS gateway.', textAlign: TextAlign.center),
          const SizedBox(height: 24),
          TextField(controller: apiKey, obscureText: true, decoration: const InputDecoration(labelText: 'API key', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: server, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Server URL', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: sim1, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'SIM 1 phone number', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: sim2, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'SIM 2 phone number (optional)', border: OutlineInputBorder())),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          const SizedBox(height: 20), FilledButton.icon(onPressed: busy ? null : submit, icon: busy ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.login), label: const Text('Connect')),
        ],
      ))),
    )))),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.state, required this.onChanged});
  final Map<String, dynamic> state; final Future<void> Function() onChanged;
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  bool sending = false;
  String timeText(int value) => value == 0 ? 'Never' : DateTime.fromMillisecondsSinceEpoch(value).toLocal().toString();
  Future<void> pulse() async { setState(() => sending = true); final ok = await NativeApi.heartbeat(); if (mounted) { setState(() => sending = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Heartbeat sent' : 'Heartbeat failed'))); await widget.onChanged(); } }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SecureNex SMS'), actions: [IconButton(onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(initial: widget.state))); await widget.onChanged(); }, icon: const Icon(Icons.settings))]),
    body: RefreshIndicator(onRefresh: widget.onChanged, child: ListView(padding: const EdgeInsets.all(16), children: [
      _phoneCard(context, 'SIM 1', widget.state['sim1'] ?? '', widget.state['sim1Outgoing'] == true),
      if ((widget.state['sim2'] ?? '').toString().isNotEmpty) _phoneCard(context, 'SIM 2', widget.state['sim2'], widget.state['sim2Outgoing'] == true),
      Card(child: ListTile(leading: const Icon(Icons.monitor_heart), title: const Text('Last heartbeat'), subtitle: Text(timeText((widget.state['lastHeartbeat'] as num?)?.toInt() ?? 0)), trailing: FilledButton(onPressed: sending ? null : pulse, child: sending ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Send')))),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Keep battery optimization disabled and allow SMS, phone-state, notification, and background permissions so the gateway can work reliably.'))),
    ])),
  );
  Widget _phoneCard(BuildContext context, String sim, String number, bool active) => Card(child: ListTile(leading: CircleAvatar(child: Text(sim.substring(sim.length - 1))), title: Text(number.isEmpty ? 'No number configured' : number), subtitle: Text(active ? 'Outgoing gateway active' : 'Outgoing gateway paused'), trailing: Icon(active ? Icons.check_circle : Icons.pause_circle, color: active ? Colors.green : Colors.orange)));
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.initial}); final Map<String, dynamic> initial;
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  late bool s1o, s2o, s1i, s2i, s1c, s2c, encrypt, logs;
  late TextEditingController key;
  @override void initState() { super.initState(); final s=widget.initial; s1o=s['sim1Outgoing']==true; s2o=s['sim2Outgoing']==true; s1i=s['sim1Incoming']==true; s2i=s['sim2Incoming']==true; s1c=s['sim1Calls']==true; s2c=s['sim2Calls']==true; encrypt=s['encrypt']==true; logs=s['debugLogs']==true; key=TextEditingController(text:s['encryptionKey']??''); }
  Future<void> save() async { await NativeApi.save({'sim1Outgoing':s1o,'sim2Outgoing':s2o,'sim1Incoming':s1i,'sim2Incoming':s2i,'sim1Calls':s1c,'sim2Calls':s2c,'encrypt':encrypt,'encryptionKey':key.text,'debugLogs':logs}); if(mounted) Navigator.pop(context); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Settings'), actions:[TextButton(onPressed:save, child:const Text('SAVE'))]), body:ListView(padding:const EdgeInsets.all(16), children:[
    const Text('SIM 1', style:TextStyle(fontWeight:FontWeight.bold)), SwitchListTile(title:const Text('Outgoing messages'), value:s1o, onChanged:(v)=>setState(()=>s1o=v)), SwitchListTile(title:const Text('Incoming messages'), value:s1i, onChanged:(v)=>setState(()=>s1i=v)), SwitchListTile(title:const Text('Missed-call events'), value:s1c, onChanged:(v)=>setState(()=>s1c=v)),
    if(widget.initial['dualSim']==true)...[const Divider(), const Text('SIM 2', style:TextStyle(fontWeight:FontWeight.bold)), SwitchListTile(title:const Text('Outgoing messages'), value:s2o, onChanged:(v)=>setState(()=>s2o=v)), SwitchListTile(title:const Text('Incoming messages'), value:s2i, onChanged:(v)=>setState(()=>s2i=v)), SwitchListTile(title:const Text('Missed-call events'), value:s2c, onChanged:(v)=>setState(()=>s2c=v))],
    const Divider(), TextField(controller:key, decoration:const InputDecoration(labelText:'Encryption key', border:OutlineInputBorder())), SwitchListTile(title:const Text('Encrypt received messages'), value:encrypt, onChanged:key.text.trim().isEmpty?null:(v)=>setState(()=>encrypt=v)), SwitchListTile(title:const Text('Debug logs'), value:logs, onChanged:(v)=>setState(()=>logs=v)),
    const SizedBox(height:20), OutlinedButton.icon(onPressed:() async { await NativeApi.logout(); if(mounted) Navigator.of(context).popUntil((r)=>r.isFirst); }, icon:const Icon(Icons.logout), label:const Text('Logout')),
  ]));
}
